import 'package:flutter/material.dart';
import 'package:le_nhut_cuong_chieut5/Screen/AlarmScreen.dart';

import 'package:le_nhut_cuong_chieut5/Screen/ProfileInfoScreen.dart';
import 'package:le_nhut_cuong_chieut5/Screen/TranslateScreen.dart';
import 'group_info_screen.dart';
import 'YoutubePlayerScreen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;

  final  List<Widget> _widgetOptions = <Widget>[
    YoutubePlayerScreen(),
    TranslateScreen(),
    AlarmScreen(),
  //  const PersonalScreen(),
    const ProfileInfoScreen(),
    const GroupInfoScreen(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Ứng dụng đa năng'),
      ),
      body: Center(
        child: _widgetOptions.elementAt(_selectedIndex),
      ),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed, // Đảm bảo tất cả các mục đều hiển thị
        items: const <BottomNavigationBarItem>[
           BottomNavigationBarItem(
            icon: Icon(Icons.play_circle_filled),
            label: 'Youtube',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.translate),
            label: 'Dịch',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.alarm),
            label: 'Báo thức',
          ),

           BottomNavigationBarItem(
            icon: Icon(Icons.person), // Icon cho thông tin
            label: 'Info Cá Nhân',
          ),
           BottomNavigationBarItem(
            icon: Icon(Icons.group),
            label: 'Nhóm',
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.blue,
        unselectedItemColor: Colors.grey,
        onTap: _onItemTapped,
      ),
    );
  }
}
