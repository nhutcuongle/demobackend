import 'dart:async';
import 'package:flutter/material.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

class StopwatchScreen extends StatefulWidget {
  const StopwatchScreen({super.key});

  @override
  State<StopwatchScreen> createState() => _StopwatchScreenState();
}

class _StopwatchScreenState extends State<StopwatchScreen> {
  final Stopwatch _stopwatch = Stopwatch();
  Timer? _timer;
  String _result = '00:00:00';

  final stt.SpeechToText _speech = stt.SpeechToText();
  bool _isListening = false;

  void _start() {
    if (_stopwatch.isRunning) return; // tránh tạo nhiều Timer
    _stopwatch.start();
    _timer ??= Timer.periodic(const Duration(milliseconds: 30), (Timer t) {
      if (!_stopwatch.isRunning) return;
      final elapsed = _stopwatch.elapsed;
      setState(() {
        _result =
        '${elapsed.inMinutes.toString().padLeft(2, '0')}:'
            '${(elapsed.inSeconds % 60).toString().padLeft(2, '0')}:'
            '${(elapsed.inMilliseconds % 1000 ~/ 10).toString().padLeft(2, '0')}';
      });
    });
  }

  void _stop() {
    _stopwatch.stop();
    _timer?.cancel();
    _timer = null;
  }

  void _reset() {
    _stopwatch.reset();
    _stop();
    setState(() {
      _result = '00:00:00';
    });
  }

  Future<void> _toggleVoiceControl() async {
    if (_isListening) {
      await _speech.stop();
      setState(() => _isListening = false);
      return;
    }

    final available = await _speech.initialize(
      onStatus: (s) => print('speech status: $s'),
      onError: (e) => print('speech error: $e'),
    );

    if (!available) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Không dùng được nhận diện giọng nói.')),
      );
      return;
    }

    setState(() => _isListening = true);

    _speech.listen(
      localeId: 'vi_VN',
      onResult: (result) {
        if (!result.finalResult) return;
        final cmd = result.recognizedWords.toLowerCase();

        if (cmd.contains('bắt đầu') || cmd.contains('start')) {
          _start();
        } else if (cmd.contains('dừng') || cmd.contains('stop')) {
          _stop();
        } else if (cmd.contains('đặt lại') || cmd.contains('reset')) {
          _reset();
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Hãy nói: "bắt đầu", "dừng" hoặc "đặt lại".'),
            ),
          );
        }

        _speech.stop();
        setState(() => _isListening = false);
      },
    );
  }

  @override
  void dispose() {
    _timer?.cancel();
    _speech.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Đồng hồ bấm giờ'),
        actions: [
          IconButton(
            onPressed: _toggleVoiceControl,
            icon: Icon(_isListening ? Icons.mic : Icons.mic_none),
            tooltip: 'Điều khiển bằng giọng nói',
          ),
        ],
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              _result,
              style: const TextStyle(fontSize: 50.0),
            ),
            const SizedBox(height: 30.0),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                ElevatedButton(
                  onPressed: _start,
                  child: const Text('Bắt đầu'),
                ),
                ElevatedButton(
                  onPressed: _stop,
                  child: const Text('Dừng'),
                ),
                ElevatedButton(
                  onPressed: _reset,
                  child: const Text('Đặt lại'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
