import 'package:flutter/material.dart';

class UnitConverterScreen extends StatefulWidget {
  const UnitConverterScreen({Key? key}) : super(key: key);

  @override
  State<UnitConverterScreen> createState() => _UnitConverterScreenState();
}

class _UnitConverterScreenState extends State<UnitConverterScreen> {
  final TextEditingController _controller = TextEditingController();
  bool _isMetersToFeet = true;
  String _resultText = 'Kết quả sẽ hiển thị ở đây';

  void _convertUnits() {
    final input = double.tryParse(_controller.text);
    if (input == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Vui lòng nhập một số hợp lệ.'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    setState(() {
      double result;
      if (_isMetersToFeet) {
        result = input * 3.28084; // m -> ft
        _resultText =
        '${input.toStringAsFixed(2)} m = ${result.toStringAsFixed(2)} ft';
      } else {
        result = input / 3.28084; // ft -> m
        _resultText =
        '${input.toStringAsFixed(2)} ft = ${result.toStringAsFixed(2)} m';
      }

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(_resultText),
          backgroundColor: Colors.green,
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Chuyển đổi đơn vị đo'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            const Text(
              'Nhập giá trị:',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _controller,
              keyboardType:
              const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(
                hintText: 'Ví dụ: 1.8',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Radio<bool>(
                  value: true,
                  groupValue: _isMetersToFeet,
                  onChanged: (_) {
                    setState(() {
                      _isMetersToFeet = true;
                    });
                  },
                ),
                const Text('Mét → Feet'),
                const SizedBox(width: 16),
                Radio<bool>(
                  value: false,
                  groupValue: _isMetersToFeet,
                  onChanged: (_) {
                    setState(() {
                      _isMetersToFeet = false;
                    });
                  },
                ),
                const Text('Feet → Mét'),
              ],
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _convertUnits,
              child: const Text('Chuyển đổi'),
            ),
            const SizedBox(height: 20),
            Text(
              _resultText,
              style:
              const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }
}
