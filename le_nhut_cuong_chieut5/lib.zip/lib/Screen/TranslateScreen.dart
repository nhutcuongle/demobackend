import 'dart:io';

import 'package:flutter/material.dart';
import 'package:google_mlkit_translation/google_mlkit_translation.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:image_picker/image_picker.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';

class TranslateScreen extends StatefulWidget {
  const TranslateScreen({super.key});

  @override
  State<TranslateScreen> createState() => _TranslateScreenState();
}

class _TranslateScreenState extends State<TranslateScreen> {
  final TextEditingController _textController = TextEditingController();
  String _translatedText = '';
  
  // Translation
  TranslateLanguage _sourceLanguage = TranslateLanguage.vietnamese;
  TranslateLanguage _targetLanguage = TranslateLanguage.english;
  OnDeviceTranslator? _translator;

  // Speech
  final stt.SpeechToText _speech = stt.SpeechToText();
  bool _isListening = false;
  bool _speechAvailable = false;

  // Image
  final ImagePicker _picker = ImagePicker();
  final TextRecognizer _textRecognizer = TextRecognizer(script: TextRecognitionScript.latin);

  @override
  void initState() {
    super.initState();
    _initSpeech();
    _initTranslator();
  }

  void _initTranslator() {
    _translator = OnDeviceTranslator(
      sourceLanguage: _sourceLanguage,
      targetLanguage: _targetLanguage,
    );
  }

  Future<void> _initSpeech() async {
    _speechAvailable = await _speech.initialize(
      onError: (e) => print('Speech error: $e'),
      onStatus: (s) => print('Speech status: $s'),
    );
    setState(() {});
  }

  @override
  void dispose() {
    _translator?.close();
    _textRecognizer.close();
    super.dispose();
  }

  Future<void> _translateText() async {
    if (_textController.text.isEmpty || _translator == null) return;
    
    final String response = await _translator!.translateText(_textController.text);
    setState(() {
      _translatedText = response;
    });
  }

  Future<void> _toggleVoiceInput() async {
    if (!_speechAvailable) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Speech recognition not available')),
      );
      return;
    }

    if (_isListening) {
      await _speech.stop();
      setState(() => _isListening = false);
    } else {
      setState(() => _isListening = true);
      await _speech.listen(
        onResult: (result) {
          setState(() {
            _textController.text = result.recognizedWords;
          });
          if (result.finalResult) {
             setState(() => _isListening = false);
             _translateText();
          }
        },
        localeId: _sourceLanguage == TranslateLanguage.vietnamese ? 'vi_VN' : 'en_US',
      );
    }
  }

  Future<void> _pickImageAndExtractText(ImageSource source) async {
    try {
      final XFile? image = await _picker.pickImage(source: source);
      if (image == null) return;

      final inputImage = InputImage.fromFilePath(image.path);
      final RecognizedText recognizedText = await _textRecognizer.processImage(inputImage);

      setState(() {
        _textController.text = recognizedText.text;
      });
      
      if (recognizedText.text.isNotEmpty) {
        await _translateText();
      } else {
         ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Không tìm thấy văn bản trong ảnh')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Lỗi: $e')),
      );
    }
  }

  void _onLanguageChanged(TranslateLanguage? language, bool isSource) {
    if (language == null) return;
    setState(() {
      if (isSource) {
        _sourceLanguage = language;
      } else {
        _targetLanguage = language;
      }
      _translator?.close();
      _initTranslator();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Dịch Thuật & Camera')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Language Selection
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                DropdownButton<TranslateLanguage>(
                  value: _sourceLanguage,
                  items: [
                    DropdownMenuItem(value: TranslateLanguage.vietnamese, child: Text('Vietnamese')),
                    DropdownMenuItem(value: TranslateLanguage.english, child: Text('English')),
                    // Add more if needed
                  ],
                  onChanged: (v) => _onLanguageChanged(v, true),
                ),
                const Icon(Icons.arrow_forward),
                DropdownButton<TranslateLanguage>(
                  value: _targetLanguage,
                  items: [
                    DropdownMenuItem(value: TranslateLanguage.vietnamese, child: Text('Vietnamese')),
                    DropdownMenuItem(value: TranslateLanguage.english, child: Text('English')),
                  ],
                  onChanged: (v) => _onLanguageChanged(v, false),
                ),
              ],
            ),
            const SizedBox(height: 20),
            
            // Input Area
            TextField(
              controller: _textController,
              decoration: InputDecoration(
                labelText: 'Nhập văn bản',
                border: const OutlineInputBorder(),
                suffixIcon: IconButton(
                  icon: Icon(_isListening ? Icons.mic : Icons.mic_none, 
                        color: _isListening ? Colors.red : null),
                  onPressed: _toggleVoiceInput,
                ),
              ),
              maxLines: 3,
            ),
            const SizedBox(height: 10),
            
            // Action Buttons
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton.icon(
                  onPressed: _translateText,
                  icon: const Icon(Icons.translate),
                  label: const Text('Dịch'),
                ),
                ElevatedButton.icon(
                  onPressed: () => _pickImageAndExtractText(ImageSource.camera),
                  icon: const Icon(Icons.camera_alt),
                  label: const Text('Chụp ảnh'),
                ),
                ElevatedButton.icon(
                  onPressed: () => _pickImageAndExtractText(ImageSource.gallery),
                  icon: const Icon(Icons.image),
                  label: const Text('Thư viện'),
                ),
              ],
            ),
            
            const SizedBox(height: 20),
            const Text('Kết quả dịch:', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.grey[200],
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                _translatedText.isNotEmpty ? _translatedText : '...',
                style: const TextStyle(fontSize: 16),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
