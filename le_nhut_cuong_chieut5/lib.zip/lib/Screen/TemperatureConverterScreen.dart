import 'package:flutter/material.dart';

enum ConversionDirection { cToF, fToC }

class TemperatureConverterScreen extends StatefulWidget {
  @override
  _TemperatureConverterScreenState createState() =>
      _TemperatureConverterScreenState();
}

class _TemperatureConverterScreenState
    extends State<TemperatureConverterScreen> {
  final TextEditingController _controller = TextEditingController();
  double? _convertedTemperature;
  ConversionDirection _conversionDirection = ConversionDirection.cToF;
  String _resultText = 'Kết quả sẽ hiển thị ở đây';

  void _convertTemperature() {
    final input = double.tryParse(_controller.text);
    if (input == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Vui lòng nhập một số hợp lệ.'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    setState(() {
      double result;
      String resultMessage;
      if (_conversionDirection == ConversionDirection.cToF) {
        result = input * 9 / 5 + 32; // C -> F
        resultMessage =
        '${input}°C là ${result.toStringAsFixed(1)}°F';
        _resultText = 'Kết quả: ${result.toStringAsFixed(1)}°F';
      } else {
        result = (input - 32) * 5 / 9; // F -> C
        resultMessage =
        '${input}°F là ${result.toStringAsFixed(1)}°C';
        _resultText = 'Kết quả: ${result.toStringAsFixed(1)}°C';
      }
      _convertedTemperature = result;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(resultMessage),
          backgroundColor: Colors.green,
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Chuyển đổi nhiệt độ'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            TextField(
              controller: _controller,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(
                labelText: 'Nhập nhiệt độ',
                hintText: 'Ví dụ: 32',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Radio<ConversionDirection>(
                  value: ConversionDirection.cToF,
                  groupValue: _conversionDirection,
                  onChanged: (ConversionDirection? value) {
                    setState(() {
                      _conversionDirection = value!;
                    });
                  },
                ),
                const Text('Celsius sang Fahrenheit'),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Radio<ConversionDirection>(
                  value: ConversionDirection.fToC,
                  groupValue: _conversionDirection,
                  onChanged: (ConversionDirection? value) {
                    setState(() {
                      _conversionDirection = value!;
                    });
                  },
                ),
                const Text('Fahrenheit sang Celsius'),
              ],
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _convertTemperature,
              child: const Text('Chuyển đổi'),
            ),
            const SizedBox(height: 20),
            Text(
              _resultText,
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }
}