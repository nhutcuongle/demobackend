import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:android_intent_plus/android_intent.dart';

class ProfileInfoScreen extends StatelessWidget {
  const ProfileInfoScreen({super.key});

  /// Gọi điện giống bên PersonalScreen
  Future<void> _makePhoneCall(String phoneNumber) async {
    final Uri launchUri = Uri(
      scheme: 'tel',
      path: phoneNumber,
    );
    if (await canLaunchUrl(launchUri)) {
      await launchUrl(launchUri);
    } else {
      throw 'Could not launch $launchUri';
    }
  }

  /// Mở app YouTube
  void _openYoutube() {
    const AndroidIntent intent = AndroidIntent(
      action: 'action_view',
      data: 'https://www.youtube.com',
    );
    intent.launch();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Info Cá Nhân'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            const SizedBox(height: 30),

            // Ảnh đại diện
            Center(
              child: CircleAvatar(
                radius: 60,
                backgroundColor: Colors.blue.shade100,
                backgroundImage: const NetworkImage('https://via.placeholder.com/150'),
                child: const Icon(Icons.person, size: 80, color: Colors.white),
              ),
            ),
            const SizedBox(height: 20),

            // Tên và Thông tin sinh viên
            const Text(
              'Lê Nhựt Cường',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),

            const SizedBox(height: 8),
            const Text(
              'Lớp: 22DTHB6',
              style: TextStyle(fontSize: 18, color: Colors.grey),
            ),

            const SizedBox(height: 5),
            const Text(
              'MSSV: 2280600342',
              style: TextStyle(fontSize: 18, color: Colors.grey),
            ),

            const SizedBox(height: 30),

            // Thông tin liên hệ
            Card(
              margin: const EdgeInsets.symmetric(horizontal: 16),
              elevation: 2,
              child: Column(
                children: [
                  // Click gọi điện
                  ListTile(
                    leading: const Icon(Icons.phone, color: Colors.green),
                    title: const Text('0817878151'),
                    onTap: () => _makePhoneCall('0817878151'),
                  ),
                  const Divider(height: 1),

                  // Click mở YouTube
                  ListTile(
                    leading: const Icon(Icons.email, color: Colors.red),
                    title: const Text('Mở YouTube'),
                    subtitle: const Text('Nhấn để mở ứng dụng YouTube'),
                    onTap: _openYoutube,
                  ),
                ],
              ),
            ),

            const SizedBox(height: 30),

            // Nút Đăng xuất
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: () {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Đã đăng xuất')),
                    );
                  },
                  icon: const Icon(Icons.logout),
                  label: const Text('Đăng xuất'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.redAccent,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 12),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }
}
